﻿using System;
using System.Xml.Linq;

namespace Swin_Adventure
{
	public class GameObject : IdentifiableObject
	{
        private string _description;
        private string _name;

        public GameObject(string[] ids, string name, string description) : base(ids)
        {
            _description = description;
            _name = name;
        }

        public string Name
		{
			get { return _name.ToLower(); }
		}

		public string ShortDescription
		{
            get { return $"a {_name.ToLower()} ({FirstId.ToLower()})"; }
        }

        public virtual string FullDescription
		{
			get { return _description; }
		}
	}
}

