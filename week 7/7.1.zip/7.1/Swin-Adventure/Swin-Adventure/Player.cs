﻿using System;
namespace Swin_Adventure
{
	public class Player : GameObject, IHaveInventory
	{
        private Inventory _inventory;

        public Player(string name, string description) : base(new string[] { "me", "inventory" }, name, description)
        {
            _inventory = new Inventory();
        }

        public GameObject Locate(string id)
		{
            if(AreYou(id))
            {
                return this;
            }
            return _inventory.Fetch(id);
        }

		public override string FullDescription
		{
			get
			{
                return "You are " + Name + ", " + base.FullDescription + ".\n"
				+ "You are carrying:\n" + Inventory.ItemList;
            }
		}

		public Inventory Inventory
		{
			get{ return _inventory; }
		}
	}
}

