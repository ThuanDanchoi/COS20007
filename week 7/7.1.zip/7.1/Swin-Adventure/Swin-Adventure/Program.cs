﻿using System;
using Swin_Adventure;

namespace Swin_Adventure;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Welcome to SwinAdventure, designed by Thuan!");

        Console.WriteLine("Enter Player Name: "); 
        string playerName = Console.ReadLine();

        Console.WriteLine("Enter your description: ");  
        string playerDescription = Console.ReadLine();

        Player player = new Player(playerName, playerDescription);

        Item item1 = new Item(new string[] { "weapon" }, "sword", "this is an Excalibur");
        Item item2 = new Item(new string[] { "armor" }, "shield", "this is a shield");
        player.Inventory.Put(item1);
        player.Inventory.Put(item2);

        Bag bag = new Bag(new string[] { "bag" }, "bag", "This is a bag.");
        player.Inventory.Put(bag);

        Item itemInBag = new Item(new string[] { "gem" }, "ruby", "This is a beautiful gem");
        bag.Inventory.Put(itemInBag);

        bool exitRequested = false;

        while (!exitRequested)
        {
            Console.WriteLine("Enter a command (or type 'exit' to quit):");
            string input = Console.ReadLine();
            string[] inputArray = input.Split(' ');

            if (inputArray.Length > 0)
            {
                string command = inputArray[0].ToLower();

                if (command == "exit" || command == "quit")
                {
                    exitRequested = true;

                }
                else
                {  
                    LookCommand lookCommand = new LookCommand();
                    string result = lookCommand.Execute(player, inputArray);

                    Console.WriteLine(result);
                }
            }
        }
    }
}

