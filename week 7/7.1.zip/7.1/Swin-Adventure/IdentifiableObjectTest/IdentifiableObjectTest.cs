﻿using NUnit.Framework;
using Swin_Adventure;

namespace IdentifiableObjectTest
{

    internal class Tests
    {
        private IdentifiableObject _test1;
        private IdentifiableObject _test2;
        private IdentifiableObject _test3;
        private IdentifiableObject _test4;
        private IdentifiableObject _test5;
        private IdentifiableObject _test6;

        [SetUp]
        public void Setup()
        {
            _test1 = new IdentifiableObject(new string[] { "fred", "bob" });
            _test2 = new IdentifiableObject(new string[] { "fred", "bob" });
            _test3 = new IdentifiableObject(new string[] { "fred", "bob" });
            _test4 = new IdentifiableObject(new string[] { "fred", "bob" });
            _test5 = new IdentifiableObject(new string[] { });
            _test6 = new IdentifiableObject(new string[] { "fred", "bob" });
        }

        [Test]
        public void TestAreYou()
        {
            Assert.IsTrue(_test1.AreYou("fred"));
            Assert.IsTrue(_test1.AreYou("bob"));
        }

        [Test]
        public void TestNotAreYou()
        {
            Assert.IsFalse(_test2.AreYou("wilma"));
            Assert.IsFalse(_test2.AreYou("boby"));
        }

        [Test]
        public void TestCaseSensitive()
        {
            Assert.IsTrue(_test3.AreYou("FRED"));
            Assert.IsTrue(_test3.AreYou("bOB"));
        }

        [Test]
        public void TestFirstID()
        {
            Assert.AreEqual("fred", _test4.FirstId);
        }

        [Test]
        public void TestFirstIdWithNoIDs()
        {
            Assert.AreEqual("", _test5.FirstId);
        }

        [Test]
        public void TestAddID()
        {
            _test6.AddIdentifier("wilma");
            Assert.IsTrue(_test6.AreYou("fred"));
            Assert.IsTrue(_test6.AreYou("bob"));
            Assert.IsTrue(_test6.AreYou("wilma"));
        }
    }
}

