﻿using System;
using Swin_Adventure;

namespace SwinAdventureTest
{
    [TestFixture]
    public class ItemTest
	{
		private Item _itemTest;
       

        [SetUp]
        public void Setup()
        {
            _itemTest = new Item(new string[] { "weapon" }, "sword", "This is an Excalibur");
            
        }

        [Test]
        public void TestItemIsIdentifiable()
        {
            Assert.IsTrue(_itemTest.AreYou("weapon"));
        }

        [Test]
        public void TestShortDescription()
        {
            Assert.IsTrue(_itemTest.ShortDescription == "a sword (weapon)");
        }

        [Test]
        public void TestFullDescription()
        {
            Assert.IsTrue(_itemTest.FullDescription == "This is an Excalibur");
        }
    }
}

