﻿using System;
namespace Swin_Adventure
{
	[TestFixture]
	public class BagTest
	{
		private Bag _bagTest1;
        private Bag _bagTest2;
        private Item _weaponTest;
        private Item _armorTest;

        [SetUp]
        public void SetUp()
		{
			_bagTest1 = new Bag(new string[] { "bag1" }, "backpack", "It's spacious");
            _bagTest2 = new Bag(new string[] { "bag2" }, "suitcase", "It's compact");
            _weaponTest = new Item(new string[] { "weapon" }, "sword", "this is an Excalibur");
            _armorTest = new Item(new string[] { "armor" }, "shield", "this is a shield");

            _bagTest1.Inventory.Put(_bagTest2);
            _bagTest1.Inventory.Put(_weaponTest);
            _bagTest2.Inventory.Put(_armorTest);
        }

        [Test]
        public void TestBagLocatesItems()
        {
           Assert.AreSame(_weaponTest, _bagTest1.Locate("weapon"));
        }

        [Test]
        public void TestBagLocatesitself()
        {
           Assert.AreSame(_bagTest1, _bagTest1.Locate("bag1"));
        }

        [Test]
        public void TestBagLocatesnothing()
        {
           Assert.IsNull(_bagTest1.Locate("bag3"));
        }

        [Test]
        public void TestBagFullDescription()
        {
           Assert.AreEqual("In the backpack you can see:\n\ta suitcase (bag2)\n\ta sword (weapon)\n", _bagTest1.FullDescription);
        }

        [Test]
        public void TestBaginBag()
        {
            Assert.AreSame(_bagTest2, _bagTest1.Locate("bag2"));
            Assert.AreSame(_weaponTest, _bagTest1.Locate("weapon"));
            Assert.IsNull(_bagTest1.Locate("armor"));
        }
    }
}

