﻿namespace Swin_Adventure;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Duc Thuan Tran - 104330455");     
    }
}

