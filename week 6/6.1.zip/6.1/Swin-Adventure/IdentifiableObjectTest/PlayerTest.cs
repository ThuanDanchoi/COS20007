﻿using System;
using Swin_Adventure;

namespace SwinAdventureTest
{
    [TestFixture]
    public class PlayerTest
    {
        private Player _playerTest;
        private Item _weaponTest;
        private Item _armorTest;

        [SetUp]
        public void Setup()
        {
            _playerTest = new Player("thuan", "dan choi");
            _weaponTest = new Item(new string[] { "weapon" }, "sword", "this is an Excalibur");
            _armorTest = new Item(new string[] { "armor" }, "shield", "this is a shield");



            _playerTest.Inventory.Put(_weaponTest);
            _playerTest.Inventory.Put(_armorTest);
        }

        [Test]
        public void TestPlayerIsIdentifiable()
        {
            Assert.IsTrue(_playerTest.AreYou("me"));
            Assert.IsTrue(_playerTest.AreYou("inventory"));
        }

        [Test]
        public void TestPlayerLocateItems()
        {
            Assert.IsTrue(_playerTest.Locate("weapon") == _weaponTest);
            Assert.IsTrue(_playerTest.Locate("armor") == _armorTest);

            Assert.IsTrue(_playerTest.Inventory.HasItem("weapon"));
            Assert.IsTrue(_playerTest.Inventory.HasItem("armor"));
        }

        [Test]
        public void TestPlayerLocateItself()
        {
            Assert.IsTrue(_playerTest == _playerTest.Locate("me"));
            Assert.IsTrue(_playerTest == _playerTest.Locate("inventory"));
        }

        [Test]
        public void TestPlayerLocateNothing()
        {
            Assert.IsTrue(_playerTest.Locate("helmet") == null);
        }

        [Test]
        public void TestPlayerFullDescription()
        {
            Assert.IsTrue(_playerTest.FullDescription == "You are thuan, dan choi.\nYou are carrying:\n\ta sword (weapon)\n\ta shield (armor)\n");
        }
    }
}

