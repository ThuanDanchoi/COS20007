﻿using System;
using Swin_Adventure;

namespace SwinAdventureTest
{
    [TestFixture]
    public class InventoryTest
	{
		private Inventory _inventoryTest;
		private Item _weaponTest;
		private Item _armorTest;

		[SetUp]
		public void SetUp()
		{
			_inventoryTest = new Inventory();
			_weaponTest = new Item(new string[] { "weapon" }, "sword", "this is an Excalibur");
            _armorTest = new Item(new string[] { "armor" }, "shield", "this is a shield");

            _inventoryTest.Put(_weaponTest);
            _inventoryTest.Put(_armorTest);
        }

        [Test]
        public void TestFindItem()
        {
            Assert.IsTrue(_inventoryTest.HasItem("weapon"));
            Assert.IsTrue(_inventoryTest.HasItem("armor"));
        }

        [Test]
        public void TestNoItemFind()
        {
            Assert.IsFalse(_inventoryTest.HasItem("axe"));
            Assert.IsFalse(_inventoryTest.HasItem("helmet"));
        }

        [Test]
        public void TestFetchItem()
        {
            Assert.IsTrue(_weaponTest == _inventoryTest.Fetch("weapon"));
            Assert.IsTrue(_inventoryTest.HasItem("weapon"));

            Assert.IsTrue(_armorTest == _inventoryTest.Fetch("armor"));
            Assert.IsTrue(_inventoryTest.HasItem("armor"));
        }

        [Test]
        public void TestTakeItem()
        {
            Assert.IsTrue(_weaponTest == _inventoryTest.Take("weapon"));
            Assert.IsFalse(_inventoryTest.HasItem("weapon"));

            Assert.IsTrue(_armorTest == _inventoryTest.Take("armor"));
            Assert.IsFalse(_inventoryTest.HasItem("armor"));
        }
         
        [Test]
        public void TestItemList()
        {
            Assert.IsTrue(_inventoryTest.ItemList.Replace("\t", "") == "a sword (weapon)\na shield (armor)\n");
        }
    }
}

