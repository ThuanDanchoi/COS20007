﻿using NUnit.Framework;
using System.Numerics;
using Swin_Adventure;

namespace SwinAdventureTest
{
    [TestFixture]
    public class TestLookCommand
    {
        private LookCommand _lookCommandTest;
        private Player _playerTest;
        private Bag _bagTest;
        private Item _gemTest;

        [SetUp]
        public void Setup()
        {
            _lookCommandTest = new LookCommand();
            _playerTest = new Player("thuan", "dan choi");
            _bagTest = new Bag(new string[] { "duffelbag" }, "duffelbag", "it's small-sized");
            _gemTest = new Item(new string[] { "gem" }, "gem", "a beautiful gem");
        }

        [Test]
        public void TestLookAtMe()
        {
            Assert.That(_lookCommandTest.Execute(_playerTest, new string[] { "look", "at", "inventory" }), Is.EqualTo("You are thuan, danchoi.\nYou are carrying:\n"));
        }

        [Test]
        public void TestLookAtGem()
        {
            _playerTest.Inventory.Put(_gemTest);

            Assert.That(_lookCommandTest.Execute(_playerTest, new string[] { "look", "at", "gem" }), Is.EqualTo("a beautiful gem"));
        }

        [Test]
        public void TestLookAtUnk()
        {
            Assert.That(_lookCommandTest.Execute(_playerTest, new string[] { "look", "at", "unknown" }), Is.EqualTo("I can't find the unknown"));
        }

        [Test]
        public void TestLookAtGemInMe()
        {
            _playerTest.Inventory.Put(_gemTest);

            Assert.That(_lookCommandTest.Execute(_playerTest, new string[] { "look", "at", "gem", "in", "inventory" }), Is.EqualTo("a beautiful gem"));
        }

        [Test]
        public void TestLookAtGemInBag()
        {
            _bagTest.Inventory.Put(_gemTest);
            _playerTest.Inventory.Put(_bagTest);

            Assert.That(_lookCommandTest.Execute(_playerTest, new string[] { "look", "at", "gem", "in", "duffelbag" }), Is.EqualTo("a beautiful gem"));
        }

        [Test]
        public void TestLookAtGemInNoBag()
        {
            Assert.That(_lookCommandTest.Execute(_playerTest, new string[] { "look", "at", "gem", "in", "duffelbag" }), Is.EqualTo("I can't find the duffelbag"));
        }

        [Test]
        public void TestLookAtNoGemInBag()
        {
            _playerTest.Inventory.Put(_bagTest);

            Assert.That(_lookCommandTest.Execute(_playerTest, new string[] { "look", "at", "gem", "in", "duffelbag" }), Is.EqualTo("I can't find the gem"));
        }

        [Test]
        public void TestInvalidLook()
        {
            Assert.That(_lookCommandTest.Execute(_playerTest, new string[] { "look", "around" }), Is.EqualTo("I don't know how to look like that"));
            Assert.That(_lookCommandTest.Execute(_playerTest, new string[] { "hello" }), Is.EqualTo("I don't know how to look like that"));
            Assert.That(_lookCommandTest.Execute(_playerTest, new string[] { "look", "at", "a", "at", "b" }), Is.EqualTo("What do you want to look in?"));
            Assert.That(_lookCommandTest.Execute(_playerTest, new string[] { "hello", "at", "a" }), Is.EqualTo("Error in look input"));
            Assert.That(_lookCommandTest.Execute(_playerTest, new string[] { "look", "by", "a" }), Is.EqualTo("What do you want to look at?"));
        }
    }
}
