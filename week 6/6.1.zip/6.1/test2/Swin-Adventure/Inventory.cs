﻿using System;
namespace Swin_Adventure
{
	public class Inventory
	{
		private List<Item> _items;
		public Inventory()
		{
			_items = new List<Item>();
		}

		public bool HasItem(string id)
		{
			foreach (Item item in _items)
			{
				if (item.AreYou(id))
				{
					return true;
				}
			}
			return false;
		}

		public void Put(Item item)
		{
			_items.Add(item);
		}

        public Item Take(string id)
        {
            Item item = Fetch(id);

            if (item != null)            
            {
                _items.Remove(item);
            }

            return item;
        }

        public Item Fetch(string id)
		{
			foreach (Item item in _items)
			{
				if (item.AreYou(id))
				{
					return item;
				}
			}
			return null;
		}

		public string ItemList
		{
			get
			{
				string list = "";
                foreach (Item item in _items)
                {
                    list += "\t" + "a " + item.Name + " (" + item.FirstId + ")\n";
                }
                return list;
            }
		}
	}
}

